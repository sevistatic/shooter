package shooter;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * a 2-d side-scrolling shooter game
 * The player uses the arrow keys to move up and down and the spacebar or mouse
 * buttons to fire.
 * @author ecslogon2
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //create a JFrame
        JFrame gameFrame = new JFrame();
        gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //create a Jpanel
        
        gameFrame.setSize((int)Toolkit.getDefaultToolkit().getScreenSize().getWidth(),
                (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight() / 2 + 100);
        gameFrame.setLocation(0, (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight() / 4);
        gameFrame.setResizable(false);
        gameFrame.setAlwaysOnTop(true);
        gameFrame.setTitle("Spencer's 2-D Shooter");
        Background background = new Background();
        background.setOpaque(false);
        
        
        gameFrame.add(background);
        gameFrame.addKeyListener(background.player);
        JOptionPane.showMessageDialog (null, "Use the arrow keys to move, press " +
                "the spacebar key to fire");
        
        gameFrame.setVisible(true);
        background.init();
        int count = 0;
        while (true){
        pause(40);
        count += 40;
        if (count % 1600 == 0){
            background.addEnemy();
        }
        background.repaint();
        background.move();
        background.label.setText("Score: " + background.getScore());
        if (background.getScore() >= 100){
            JOptionPane.showMessageDialog(null, "YOU WIN!!! YAY!!");
        }
        }
        //add a background image to the JPanel
        
        //add a keylistener to the JPanel to make the background scroll faster 
        //when right is pressed, and slower when left is pressed
        
        //make a class of objects called enemies, they die when shot and hurt 
        //when run into, make them listen for the left and right arrows
        
        //make a class of objects called obstacles, they don't blow up, and hurt
        //when run into, they slow and speed up with left and right arrows
        
        //make a player icon, it can shoot projectiles, flashes when hit, and 
        //moves up, down, left, right
        
        //make a button for fire
                
        //make it listen for mouseclick
                
        //make a collide method
        
        //make a JLabel for score
        
        //make it listen for an enemy collision event
        
        //create win condition: gain 20 points
        
        //create lose condition: miss 10 times


        
    }
public static void pause (int ms) {
    try {
       Thread.sleep (ms);
    } catch (Exception e) {
        e.printStackTrace ();
    }
} // end method pause

}
