package shooter;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author ecslogon2
 */
public class Background extends JPanel {
    int score;
JLabel label;
    Image image;
    //EnergyWave wave;
    private int beginningPixel1 = 0;
    private int beginningPixel2 = 0;
    public Player player;
    private ArrayList<Enemy> eList = new ArrayList();
   // int initialDelay = 30000; // start after 30 seconds
   // int interval = 2000;        // repeat every 3 seconds
    //private Timer timer = new Timer();
    int randomX;
    int randomSize;
    boolean busy = false;

    public Background() {
        label = new JLabel("Score: " + getScore());
        image = new ImageIcon("bg.jpg").getImage();
        // wave = new EnergyWave(); 
        player = new Player();
        addKeyListener(player);
        this.add(label);
//        start();//       missile = new Missile();
    }

    public int getRandomX() {
        randomX = (int) (Math.random() * (getWidth() * 1 / 3));
        return randomX;
    }

    public int getRandomSize() {
        randomSize = (int) (1 + Math.random() * 2);
        return randomSize;
    }

    public void addEnemy(){
        eList.add(new Enemy(900 + getRandomX(), getRandomSize()));
    }

//    public void start() {
//        timer.scheduleAtFixedRate(new TimerTask() {
//
 //           public void run() {
 //               if (!busy) {
 //                   busy = true;
  //                  eList.add(new Enemy(900 + getRandomX(), getRandomSize()));
  //                  busy = false;
  //              }
 //           }
  //      }, 1000, interval);
 //   }

    public void init() {
        beginningPixel1 = 0;
        beginningPixel2 = beginningPixel1 + image.getWidth(null);
    }

    public void move() {
        changePixel(2);
        //if enemy's hit walls, they change direction
        if (!eList.isEmpty()) {
            if (!busy) {
                for (Enemy enemy : eList) {
                    if (enemy.getYCoord() + enemy.getHeight() > this.getHeight() ||
                            enemy.getYCoord() < 0) {
                        enemy.changeDirection();
                    }

                    //screen scrolls faster if player moves right
                    if (player.isMovingRight()) {
                        changePixel(4);
                    }
                    enemy.move();
                }
            }
        }
        player.move();
        boolean hasCollided = false;
        if (player.missileExists() && !eList.isEmpty()) {
            for (int i = 0; i < eList.size(); i++) {
                hasCollided = detectCollision(player.getMissile(), eList.get(i));
                if (hasCollided) {
                    processCollision(player.getMissile(), eList.get(i));

                }

            }
            hasCollided = false;
            if (player.getMissile() != null) {
                if (player.getMissile().getXCoord() > this.getWidth()) {
                    player.destroyMissile();
                }
            }
        }
    }

    public int getScore(){
        return score;
    }


    public boolean detectCollision(Missile missile, Enemy enemy) {
        if (!busy) {
            if (enemy != null && missile != null) {
                busy = true;
                if ((missile.getTipX() >= enemy.getXCoord() &&
                     missile.getTipX() + missile.getWidth() <= enemy.getXCoord() +
                     enemy.getWidth()) &&
                     Math.abs(enemy.getCenterY() - missile.getTipY()) < 500) {
                    busy = false;
                    return true;
                }
                busy = false;
            }
            return false;
        } else {
            return false;
        }
    }

    public void processCollision(Missile missile, Enemy enemy) {
        if (!busy){System.out.println("Pow!");
        player.destroyMissile();
        eList.remove(enemy);
        score += 10;
        }
    }

//            missile.move();
//            missileDistance += 10;
//        }
//        spacebarTyped = false;
    public void changePixel(int speed) {
        if (beginningPixel2 < 1) {
            beginningPixel1 = 0;
            beginningPixel2 =
                    getWidth() / 2;
        }

        this.beginningPixel1 -= speed;
        this.beginningPixel2 -= speed;
    }

    public void paintComponent(Graphics g) {

        label.setOpaque(true);
        player.setPanelHeight(getHeight());
        player.setPanelWidth(getWidth());
        //draw background
        g.drawImage(image, beginningPixel1, 0, getWidth(), getHeight(), null);
        g.drawImage(image, beginningPixel2, 0, getWidth(), getHeight(), null);

        //draw ship
        if (!player.isMovingRight()) {
            g.drawImage(player.getShip(false), player.getX(), player.getY(), player.getWidth(),
                    player.getHeight(), null);
        } else {
            g.drawImage(player.getShip(true), player.getX(), player.getY(), player.getWidth(),
                    player.getHeight(), null);
        }

        //draw missile
        if (player.missileExists()) {
            g.drawImage(player.getMissile().getImage(), player.getMissile().getXCoord(),
                    player.getMissile().getYCoord(), null);

        //----------------this is for after the project is graded!!!!
//            g.drawImage(wave.startWave(), player.getxPos() - 20 + player.getWidth(),
//                    getGunHeight(), null);
//           g.drawImage(wave.startWave(), player.getxPos() - 20 + player.getWidth(),
//                    getGunHeight(), null);
//           g.drawImage(wave.getImage(), player.getxPos() - 20 + player.getWidth() +
//                   wave.startWave().getWidth(this), getGunHeight(), null);
//           
        }
        
            for (Enemy e : eList) {
                if (eList != null) {
                g.drawImage(e.getImage(), e.getX(), e.getY(), e.getWidth(), e.getHeight(), null);
            }
        }
    } // end method paintComponent
}//end class

    

