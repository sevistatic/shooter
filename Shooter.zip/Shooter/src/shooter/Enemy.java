package shooter;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Enemy extends JComponent{

    
    private int y;
    private int x;
    private int centerX;
    private int centerY;
    private double rate = 10;
    Point centerPoint;

    Enemy(int xLoc, int size){
        centerX = getCenterX();
        centerPoint = new Point(centerX, centerY);
        y = 20;
        x = xLoc;
        this.setLocation(x, y);
        this.setSize(getImage().getWidth(this) * size, getImage().getHeight(this) * size);
    }

    public Point getCenterPoint() {
        return centerPoint;
    }
    
    public Image getImage(){
        return new ImageIcon("pod.png").getImage();
    }
    
public void changeDirection(){
    rate = - rate;
}

public int getCenterY(){
    int center = this.y + (getHeight() / 2);
    return center;
}

public int getCenterX(){
    int center = this.x + (getWidth() / 2);
    return center;
} 

    public void move(){
//        int newY = (int)(radius * Math.sin(rate));
//        int newX = (int)(radius * Math.cos(rate));
//        rate += speed;
        this.setLocation(x, y);
        y += rate;
    }
public int getYCoord(){
    return y;
}

   public int getXCoord(){
       return x;
   }
}

